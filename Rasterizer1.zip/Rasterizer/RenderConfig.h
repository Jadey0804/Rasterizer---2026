#pragma once

struct RenderConfig {

	bool LightOpt = false;
};