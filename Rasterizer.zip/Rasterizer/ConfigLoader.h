#pragma once

#include "RenderConfig.h"

bool LoadConfig(RenderConfig& cfg, const char* filename);