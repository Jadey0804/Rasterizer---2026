#pragma once

const bool useLightOPT = true;
const bool useEdgeRaster = true;
//const bool useFastNormalizeOPT = true;
const bool useRenderOPT = true;
const bool useScene1SharedMeshOPT = false;
const bool useBackfaceCulling = true;
//const bool useFrustumCullingClip = true;
const bool useSIMD = false;